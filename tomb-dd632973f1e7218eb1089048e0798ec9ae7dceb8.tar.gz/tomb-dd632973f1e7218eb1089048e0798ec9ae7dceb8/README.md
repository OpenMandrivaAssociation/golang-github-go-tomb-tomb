Installation and usage
----------------------

See [gopkg.in/tomb.v1](https://gopkg.in/tomb.v1) for documentation and usage details.
